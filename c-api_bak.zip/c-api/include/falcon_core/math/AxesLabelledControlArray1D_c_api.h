#pragma once
#ifdef __cplusplus
    extern "C" {
#endif
#include "falcon_core/math/arrays/LabelledControlArray1D_c_api.h"
#include "falcon_core/generic/ListLabelledControlArray1D_c_api.h"
#include <stddef.h>
#include <stdbool.h>
#include "falcon_core/generic/String_c_api.h"

// Forward declarations for opaque handles
typedef void* AxesLabelledControlArray1DHandle;
// Function declarations

AxesLabelledControlArray1DHandle AxesLabelledControlArray1D_create_empty();
AxesLabelledControlArray1DHandle AxesLabelledControlArray1D_create_raw(const LabelledControlArray1DHandle* data, size_t count);
AxesLabelledControlArray1DHandle AxesLabelledControlArray1D_create(ListLabelledControlArray1DHandle data);
void AxesLabelledControlArray1D_destroy(AxesLabelledControlArray1DHandle handle);
void AxesLabelledControlArray1D_push_back(AxesLabelledControlArray1DHandle handle, LabelledControlArray1DHandle value);
size_t AxesLabelledControlArray1D_size(AxesLabelledControlArray1DHandle handle);
bool AxesLabelledControlArray1D_empty(AxesLabelledControlArray1DHandle handle);
void AxesLabelledControlArray1D_erase_at(AxesLabelledControlArray1DHandle handle, size_t idx);
void AxesLabelledControlArray1D_clear(AxesLabelledControlArray1DHandle handle);
LabelledControlArray1DHandle AxesLabelledControlArray1D_at(AxesLabelledControlArray1DHandle handle, size_t idx);
size_t AxesLabelledControlArray1D_items(AxesLabelledControlArray1DHandle handle, LabelledControlArray1DHandle* out_buffer, size_t buffer_size);
bool AxesLabelledControlArray1D_contains(AxesLabelledControlArray1DHandle handle, LabelledControlArray1DHandle value);
size_t AxesLabelledControlArray1D_index(AxesLabelledControlArray1DHandle handle, LabelledControlArray1DHandle value);
AxesLabelledControlArray1DHandle AxesLabelledControlArray1D_intersection(AxesLabelledControlArray1DHandle handle, AxesLabelledControlArray1DHandle other);
bool AxesLabelledControlArray1D_equal(AxesLabelledControlArray1DHandle a, AxesLabelledControlArray1DHandle b);
bool AxesLabelledControlArray1D_not_equal(AxesLabelledControlArray1DHandle a, AxesLabelledControlArray1DHandle b);

// Serialization (from Song)
StringHandle      AxesLabelledControlArray1D_to_json_string(AxesLabelledControlArray1DHandle handle);
AxesLabelledControlArray1DHandle AxesLabelledControlArray1D_from_json_string(StringHandle json);

#ifdef __cplusplus
}
#endif