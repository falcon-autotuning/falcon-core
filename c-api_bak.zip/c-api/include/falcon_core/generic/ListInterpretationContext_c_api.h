#pragma once
#ifdef __cplusplus
    extern "C" {
#endif
#include "falcon_core/autotuner_interfaces/interpretations/InterpretationContext_c_api.h"
#include <stddef.h>
#include <stdbool.h>
#include "falcon_core/generic/String_c_api.h"

// Forward declarations for opaque handles
typedef void* ListInterpretationContextHandle;
// Function declarations

ListInterpretationContextHandle ListInterpretationContext_create_empty();

ListInterpretationContextHandle ListInterpretationContext_fill_value(size_t count, InterpretationContextHandle value);
ListInterpretationContextHandle ListInterpretationContext_create(InterpretationContextHandle* data, size_t count);
void ListInterpretationContext_destroy(ListInterpretationContextHandle handle);
void ListInterpretationContext_push_back(ListInterpretationContextHandle handle, InterpretationContextHandle value);
size_t ListInterpretationContext_size(ListInterpretationContextHandle handle);
bool ListInterpretationContext_empty(ListInterpretationContextHandle handle);
void ListInterpretationContext_erase_at(ListInterpretationContextHandle handle, size_t idx);
void ListInterpretationContext_clear(ListInterpretationContextHandle handle);
InterpretationContextHandle ListInterpretationContext_at(ListInterpretationContextHandle handle, size_t idx);
size_t ListInterpretationContext_items(ListInterpretationContextHandle handle, InterpretationContextHandle* out_buffer, size_t buffer_size);
bool ListInterpretationContext_contains(ListInterpretationContextHandle handle, InterpretationContextHandle value);
size_t ListInterpretationContext_index(ListInterpretationContextHandle handle, InterpretationContextHandle value);
ListInterpretationContextHandle ListInterpretationContext_intersection(ListInterpretationContextHandle handle, ListInterpretationContextHandle other);
bool ListInterpretationContext_equal(ListInterpretationContextHandle a, ListInterpretationContextHandle b);
bool ListInterpretationContext_not_equal(ListInterpretationContextHandle a, ListInterpretationContextHandle b);

// Serialization (from Song)
StringHandle      ListInterpretationContext_to_json_string(ListInterpretationContextHandle handle);
ListInterpretationContextHandle ListInterpretationContext_from_json_string(StringHandle json);

#ifdef __cplusplus
}
#endif