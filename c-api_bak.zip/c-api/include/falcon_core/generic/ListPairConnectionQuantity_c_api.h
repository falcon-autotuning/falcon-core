#pragma once
#ifdef __cplusplus
    extern "C" {
#endif
#include "falcon_core/generic/PairConnectionQuantity_c_api.h"
#include <stddef.h>
#include <stdbool.h>
#include "falcon_core/generic/String_c_api.h"

// Forward declarations for opaque handles
typedef void* ListPairConnectionQuantityHandle;
// Function declarations

ListPairConnectionQuantityHandle ListPairConnectionQuantity_create_empty();

ListPairConnectionQuantityHandle ListPairConnectionQuantity_fill_value(size_t count, PairConnectionQuantityHandle value);
ListPairConnectionQuantityHandle ListPairConnectionQuantity_create(PairConnectionQuantityHandle* data, size_t count);
void ListPairConnectionQuantity_destroy(ListPairConnectionQuantityHandle handle);
void ListPairConnectionQuantity_push_back(ListPairConnectionQuantityHandle handle, PairConnectionQuantityHandle value);
size_t ListPairConnectionQuantity_size(ListPairConnectionQuantityHandle handle);
bool ListPairConnectionQuantity_empty(ListPairConnectionQuantityHandle handle);
void ListPairConnectionQuantity_erase_at(ListPairConnectionQuantityHandle handle, size_t idx);
void ListPairConnectionQuantity_clear(ListPairConnectionQuantityHandle handle);
PairConnectionQuantityHandle ListPairConnectionQuantity_at(ListPairConnectionQuantityHandle handle, size_t idx);
size_t ListPairConnectionQuantity_items(ListPairConnectionQuantityHandle handle, PairConnectionQuantityHandle* out_buffer, size_t buffer_size);
bool ListPairConnectionQuantity_contains(ListPairConnectionQuantityHandle handle, PairConnectionQuantityHandle value);
size_t ListPairConnectionQuantity_index(ListPairConnectionQuantityHandle handle, PairConnectionQuantityHandle value);
ListPairConnectionQuantityHandle ListPairConnectionQuantity_intersection(ListPairConnectionQuantityHandle handle, ListPairConnectionQuantityHandle other);
bool ListPairConnectionQuantity_equal(ListPairConnectionQuantityHandle a, ListPairConnectionQuantityHandle b);
bool ListPairConnectionQuantity_not_equal(ListPairConnectionQuantityHandle a, ListPairConnectionQuantityHandle b);

// Serialization (from Song)
StringHandle      ListPairConnectionQuantity_to_json_string(ListPairConnectionQuantityHandle handle);
ListPairConnectionQuantityHandle ListPairConnectionQuantity_from_json_string(StringHandle json);

#ifdef __cplusplus
}
#endif