#pragma once
#ifdef __cplusplus
    extern "C" {
#endif
#include <stddef.h>
#include <stdbool.h>
#include "falcon_core/generic/String_c_api.h"
#include "falcon_core/generic/String_c_api.h"

// Forward declarations for opaque handles
typedef void* PairStringBoolHandle;
// Function declarations

/* AUTO-DOC from cpp: PairStringBool_create | falcon_core::generic::Pair::create */
/**
 * @brief (from C++: falcon_core::generic::Pair::create)
 * @brief Store a pair of values.
 * @param first The first value.
 * @param second The second value.
 */
PairStringBoolHandle PairStringBool_create(StringHandle first, bool second);
void PairStringBool_destroy(PairStringBoolHandle handle);
/* AUTO-DOC from cpp: PairStringBool_first | falcon_core::generic::Pair::first */
/**
 * @brief (from C++: falcon_core::generic::Pair::first)
 * @brief Get the stored first value.
 */
StringHandle PairStringBool_first(PairStringBoolHandle handle);
/* AUTO-DOC from cpp: PairStringBool_second | falcon_core::generic::Pair::second */
/**
 * @brief (from C++: falcon_core::generic::Pair::second)
 * @brief Get the stored second value.
 */
bool PairStringBool_second(PairStringBoolHandle handle);
bool PairStringBool_equal(PairStringBoolHandle a, PairStringBoolHandle b);
bool PairStringBool_not_equal(PairStringBoolHandle a, PairStringBoolHandle b);
// Serialization (from Song)
/* AUTO-DOC from cpp: PairStringBool_to_json_string | falcon_core::generic::Song::to_json_string */
/**
 * @brief (from C++: falcon_core::generic::Song::to_json_string)
 * @brief Serialize this object to a JSON string.
 */
StringHandle      PairStringBool_to_json_string(PairStringBoolHandle handle);
/* AUTO-DOC from cpp: PairStringBool_from_json_string | falcon_core::generic::Song::from_json_string */
/**
 * @brief (from C++: falcon_core::generic::Song::from_json_string)
 * @brief Deserialize an object from a JSON string.
 * @return std::shared_ptr<Song> (actually the derived type)
 */
PairStringBoolHandle PairStringBool_from_json_string(StringHandle json);

#ifdef __cplusplus
}
#endif