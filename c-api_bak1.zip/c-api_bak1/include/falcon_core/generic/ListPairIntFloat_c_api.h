#pragma once
#ifdef __cplusplus
    extern "C" {
#endif
#include "falcon_core/generic/PairIntFloat_c_api.h"
#include <stddef.h>
#include <stdbool.h>
#include "falcon_core/generic/String_c_api.h"

// Forward declarations for opaque handles
typedef void* ListPairIntFloatHandle;
// Function declarations

ListPairIntFloatHandle ListPairIntFloat_create_empty();

ListPairIntFloatHandle ListPairIntFloat_fill_value(size_t count, PairIntFloatHandle value);
ListPairIntFloatHandle ListPairIntFloat_create(PairIntFloatHandle* data, size_t count);
void ListPairIntFloat_destroy(ListPairIntFloatHandle handle);
void ListPairIntFloat_push_back(ListPairIntFloatHandle handle, PairIntFloatHandle value);
size_t ListPairIntFloat_size(ListPairIntFloatHandle handle);
bool ListPairIntFloat_empty(ListPairIntFloatHandle handle);
/* AUTO-DOC from cpp: ListPairIntFloat_erase_at | falcon_core::generic::List::erase_at */
/**
 * @brief (from C++: falcon_core::generic::List::erase_at)
 * @brief Allows for targetted eraseall of elements at an index.
 * @param idx The index to erase at.
 */
void ListPairIntFloat_erase_at(ListPairIntFloatHandle handle, size_t idx);
/* AUTO-DOC from cpp: ListPairIntFloat_clear | falcon_core::generic::List::clear */
/**
 * @brief (from C++: falcon_core::generic::List::clear)
 * @brief clears to contents of the list.
 */
void ListPairIntFloat_clear(ListPairIntFloatHandle handle);
PairIntFloatHandle ListPairIntFloat_at(ListPairIntFloatHandle handle, size_t idx);
size_t ListPairIntFloat_items(ListPairIntFloatHandle handle, PairIntFloatHandle* out_buffer, size_t buffer_size);
bool ListPairIntFloat_contains(ListPairIntFloatHandle handle, PairIntFloatHandle value);
size_t ListPairIntFloat_index(ListPairIntFloatHandle handle, PairIntFloatHandle value);
/* AUTO-DOC from cpp: ListPairIntFloat_intersection | falcon_core::generic::List::intersection */
/**
 * @brief (from C++: falcon_core::generic::List::intersection)
 * @brief Finds the intersection between this list and another.
 * @param other the other list to compare again.
 * @returns A list of values containing elements from both.
 */
ListPairIntFloatHandle ListPairIntFloat_intersection(ListPairIntFloatHandle handle, ListPairIntFloatHandle other);
bool ListPairIntFloat_equal(ListPairIntFloatHandle a, ListPairIntFloatHandle b);
bool ListPairIntFloat_not_equal(ListPairIntFloatHandle a, ListPairIntFloatHandle b);

// Serialization (from Song)
/* AUTO-DOC from cpp: ListPairIntFloat_to_json_string | falcon_core::generic::Song::to_json_string */
/**
 * @brief (from C++: falcon_core::generic::Song::to_json_string)
 * @brief Serialize this object to a JSON string.
 */
StringHandle      ListPairIntFloat_to_json_string(ListPairIntFloatHandle handle);
/* AUTO-DOC from cpp: ListPairIntFloat_from_json_string | falcon_core::generic::Song::from_json_string */
/**
 * @brief (from C++: falcon_core::generic::Song::from_json_string)
 * @brief Deserialize an object from a JSON string.
 * @return std::shared_ptr<Song> (actually the derived type)
 */
ListPairIntFloatHandle ListPairIntFloat_from_json_string(StringHandle json);

#ifdef __cplusplus
}
#endif