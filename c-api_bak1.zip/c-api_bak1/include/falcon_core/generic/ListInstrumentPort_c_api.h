#pragma once
#ifdef __cplusplus
    extern "C" {
#endif
#include "falcon_core/instrument_interfaces/names/InstrumentPort_c_api.h"
#include <stddef.h>
#include <stdbool.h>
#include "falcon_core/generic/String_c_api.h"

// Forward declarations for opaque handles
typedef void* ListInstrumentPortHandle;
// Function declarations

ListInstrumentPortHandle ListInstrumentPort_create_empty();

ListInstrumentPortHandle ListInstrumentPort_fill_value(size_t count, InstrumentPortHandle value);
ListInstrumentPortHandle ListInstrumentPort_create(InstrumentPortHandle* data, size_t count);
void ListInstrumentPort_destroy(ListInstrumentPortHandle handle);
void ListInstrumentPort_push_back(ListInstrumentPortHandle handle, InstrumentPortHandle value);
size_t ListInstrumentPort_size(ListInstrumentPortHandle handle);
bool ListInstrumentPort_empty(ListInstrumentPortHandle handle);
/* AUTO-DOC from cpp: ListInstrumentPort_erase_at | falcon_core::generic::List::erase_at */
/**
 * @brief (from C++: falcon_core::generic::List::erase_at)
 * @brief Allows for targetted eraseall of elements at an index.
 * @param idx The index to erase at.
 */
void ListInstrumentPort_erase_at(ListInstrumentPortHandle handle, size_t idx);
/* AUTO-DOC from cpp: ListInstrumentPort_clear | falcon_core::generic::List::clear */
/**
 * @brief (from C++: falcon_core::generic::List::clear)
 * @brief clears to contents of the list.
 */
void ListInstrumentPort_clear(ListInstrumentPortHandle handle);
InstrumentPortHandle ListInstrumentPort_at(ListInstrumentPortHandle handle, size_t idx);
size_t ListInstrumentPort_items(ListInstrumentPortHandle handle, InstrumentPortHandle* out_buffer, size_t buffer_size);
bool ListInstrumentPort_contains(ListInstrumentPortHandle handle, InstrumentPortHandle value);
size_t ListInstrumentPort_index(ListInstrumentPortHandle handle, InstrumentPortHandle value);
/* AUTO-DOC from cpp: ListInstrumentPort_intersection | falcon_core::generic::List::intersection */
/**
 * @brief (from C++: falcon_core::generic::List::intersection)
 * @brief Finds the intersection between this list and another.
 * @param other the other list to compare again.
 * @returns A list of values containing elements from both.
 */
ListInstrumentPortHandle ListInstrumentPort_intersection(ListInstrumentPortHandle handle, ListInstrumentPortHandle other);
bool ListInstrumentPort_equal(ListInstrumentPortHandle a, ListInstrumentPortHandle b);
bool ListInstrumentPort_not_equal(ListInstrumentPortHandle a, ListInstrumentPortHandle b);

// Serialization (from Song)
/* AUTO-DOC from cpp: ListInstrumentPort_to_json_string | falcon_core::generic::Song::to_json_string */
/**
 * @brief (from C++: falcon_core::generic::Song::to_json_string)
 * @brief Serialize this object to a JSON string.
 */
StringHandle      ListInstrumentPort_to_json_string(ListInstrumentPortHandle handle);
/* AUTO-DOC from cpp: ListInstrumentPort_from_json_string | falcon_core::generic::Song::from_json_string */
/**
 * @brief (from C++: falcon_core::generic::Song::from_json_string)
 * @brief Deserialize an object from a JSON string.
 * @return std::shared_ptr<Song> (actually the derived type)
 */
ListInstrumentPortHandle ListInstrumentPort_from_json_string(StringHandle json);

#ifdef __cplusplus
}
#endif