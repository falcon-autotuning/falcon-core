#pragma once
#ifdef __cplusplus
    extern "C" {
#endif
#include "falcon_core/generic/ListPairStringString_c_api.h"
#include "falcon_core/generic/ListString_c_api.h"
#include <stddef.h>
#include <stdbool.h>
#include "falcon_core/generic/String_c_api.h"

// Forward declarations for opaque handles
typedef void* MapStringStringHandle;
// Function declarations

MapStringStringHandle MapStringString_create_empty();
MapStringStringHandle MapStringString_create(const PairStringStringHandle* data, size_t count);
void MapStringString_destroy(MapStringStringHandle handle);
void MapStringString_insert_or_assign(MapStringStringHandle handle, const StringHandle key, const StringHandle value);
void MapStringString_insert(MapStringStringHandle handle, const StringHandle key, const StringHandle value);
StringHandle MapStringString_at(MapStringStringHandle handle, const StringHandle key);
void MapStringString_erase(MapStringStringHandle handle, const StringHandle key);
size_t MapStringString_size(MapStringStringHandle handle);
bool MapStringString_empty(MapStringStringHandle handle);
void MapStringString_clear(MapStringStringHandle handle);
bool MapStringString_contains(MapStringStringHandle handle, const StringHandle key);
/* AUTO-DOC from cpp: MapStringString_keys | falcon_core::generic::Map::keys */
/**
 * @brief (from C++: falcon_core::generic::Map::keys)
 * @brief Return the keys of the Map.
 */
ListStringHandle MapStringString_keys(MapStringStringHandle handle);
/* AUTO-DOC from cpp: MapStringString_values | falcon_core::generic::Map::values */
/**
 * @brief (from C++: falcon_core::generic::Map::values)
 * @brief Return the values of the Map.
 */
ListStringHandle MapStringString_values(MapStringStringHandle handle);
ListPairStringStringHandle MapStringString_items(MapStringStringHandle handle);
bool MapStringString_equal(MapStringStringHandle a, MapStringStringHandle b);
bool MapStringString_not_equal(MapStringStringHandle a, MapStringStringHandle b);
// Serialization (from Song)
/* AUTO-DOC from cpp: MapStringString_to_json_string | falcon_core::generic::Song::to_json_string */
/**
 * @brief (from C++: falcon_core::generic::Song::to_json_string)
 * @brief Serialize this object to a JSON string.
 */
StringHandle      MapStringString_to_json_string(MapStringStringHandle handle);
/* AUTO-DOC from cpp: MapStringString_from_json_string | falcon_core::generic::Song::from_json_string */
/**
 * @brief (from C++: falcon_core::generic::Song::from_json_string)
 * @brief Deserialize an object from a JSON string.
 * @return std::shared_ptr<Song> (actually the derived type)
 */
MapStringStringHandle MapStringString_from_json_string(StringHandle json);

#ifdef __cplusplus
}
#endif