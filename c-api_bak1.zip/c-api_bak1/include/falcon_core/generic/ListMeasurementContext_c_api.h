#pragma once
#ifdef __cplusplus
    extern "C" {
#endif
#include "falcon_core/autotuner_interfaces/contexts/MeasurementContext_c_api.h"
#include <stddef.h>
#include <stdbool.h>
#include "falcon_core/generic/String_c_api.h"

// Forward declarations for opaque handles
typedef void* ListMeasurementContextHandle;
// Function declarations

ListMeasurementContextHandle ListMeasurementContext_create_empty();

ListMeasurementContextHandle ListMeasurementContext_fill_value(size_t count, MeasurementContextHandle value);
ListMeasurementContextHandle ListMeasurementContext_create(MeasurementContextHandle* data, size_t count);
void ListMeasurementContext_destroy(ListMeasurementContextHandle handle);
void ListMeasurementContext_push_back(ListMeasurementContextHandle handle, MeasurementContextHandle value);
size_t ListMeasurementContext_size(ListMeasurementContextHandle handle);
bool ListMeasurementContext_empty(ListMeasurementContextHandle handle);
/* AUTO-DOC from cpp: ListMeasurementContext_erase_at | falcon_core::generic::List::erase_at */
/**
 * @brief (from C++: falcon_core::generic::List::erase_at)
 * @brief Allows for targetted eraseall of elements at an index.
 * @param idx The index to erase at.
 */
void ListMeasurementContext_erase_at(ListMeasurementContextHandle handle, size_t idx);
/* AUTO-DOC from cpp: ListMeasurementContext_clear | falcon_core::generic::List::clear */
/**
 * @brief (from C++: falcon_core::generic::List::clear)
 * @brief clears to contents of the list.
 */
void ListMeasurementContext_clear(ListMeasurementContextHandle handle);
MeasurementContextHandle ListMeasurementContext_at(ListMeasurementContextHandle handle, size_t idx);
size_t ListMeasurementContext_items(ListMeasurementContextHandle handle, MeasurementContextHandle* out_buffer, size_t buffer_size);
bool ListMeasurementContext_contains(ListMeasurementContextHandle handle, MeasurementContextHandle value);
size_t ListMeasurementContext_index(ListMeasurementContextHandle handle, MeasurementContextHandle value);
/* AUTO-DOC from cpp: ListMeasurementContext_intersection | falcon_core::generic::List::intersection */
/**
 * @brief (from C++: falcon_core::generic::List::intersection)
 * @brief Finds the intersection between this list and another.
 * @param other the other list to compare again.
 * @returns A list of values containing elements from both.
 */
ListMeasurementContextHandle ListMeasurementContext_intersection(ListMeasurementContextHandle handle, ListMeasurementContextHandle other);
bool ListMeasurementContext_equal(ListMeasurementContextHandle a, ListMeasurementContextHandle b);
bool ListMeasurementContext_not_equal(ListMeasurementContextHandle a, ListMeasurementContextHandle b);

// Serialization (from Song)
/* AUTO-DOC from cpp: ListMeasurementContext_to_json_string | falcon_core::generic::Song::to_json_string */
/**
 * @brief (from C++: falcon_core::generic::Song::to_json_string)
 * @brief Serialize this object to a JSON string.
 */
StringHandle      ListMeasurementContext_to_json_string(ListMeasurementContextHandle handle);
/* AUTO-DOC from cpp: ListMeasurementContext_from_json_string | falcon_core::generic::Song::from_json_string */
/**
 * @brief (from C++: falcon_core::generic::Song::from_json_string)
 * @brief Deserialize an object from a JSON string.
 * @return std::shared_ptr<Song> (actually the derived type)
 */
ListMeasurementContextHandle ListMeasurementContext_from_json_string(StringHandle json);

#ifdef __cplusplus
}
#endif